from setuptools import setup, find_packages

setup(
    name="miCuartoRepo",                           # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Daniel Pinto",                         # Tu nombre
    author_email="numberx07@gmail.com",                 # Tu correo electrónico
    url="https://github.com/ddpinto7/miCuartoRepo",     # URL del proyecto
)